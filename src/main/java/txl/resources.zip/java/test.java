public class MyClass {
	public static void main(String args[]) { /* A comment */
		System.out.println("Hello World!"); /* A comment */ }
}
